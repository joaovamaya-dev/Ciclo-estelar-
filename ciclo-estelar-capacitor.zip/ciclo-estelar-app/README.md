# Ciclo Estelar — APK debug

Projeto Capacitor 6 que empacota `www/index.html` (WebGL, ciclo estelar em 3D, da nuvem ao buraco negro).

## Opção A: sem instalar nada (GitHub Actions)
1. Crie um repositório no GitHub e envie estes arquivos.
2. Aba Actions > "APK debug" > Run workflow.
3. Baixe `ciclo-estelar-debug-apk` em Artifacts, extraia e instale `app-debug.apk`.

## Opção B: no seu computador
Requisitos: Node 18+, JDK 17, Android SDK.
    ./setup.sh
APK em `android/app/build/outputs/apk/debug/app-debug.apk`.
Instalar: `adb install -r android/app/build/outputs/apk/debug/app-debug.apk`

## Notas
- Para editar o visual, mude `www/index.html` e rode `npx cap sync android`.
- As fontes vêm do Google Fonts; sem internet o app usa fontes do sistema.
