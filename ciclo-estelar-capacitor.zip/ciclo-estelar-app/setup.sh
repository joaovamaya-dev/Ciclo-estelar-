#!/usr/bin/env bash
# Gera o APK debug localmente. Requer Node 18+, JDK 17 e Android SDK (ANDROID_HOME).
set -e
npm install
[ -d android ] || npx cap add android
npx cap sync android
(cd android && chmod +x gradlew && ./gradlew assembleDebug)
echo "APK: android/app/build/outputs/apk/debug/app-debug.apk"
